package com.achievemeaalk.freedjf.ui.onboarding

const val onboardingRoute = "onboarding"
const val firstAccountPromptRoute = "first_account_prompt"
const val firstAccountSuccessRoute = "first_account_success"
const val paywallRoute = "paywall"
