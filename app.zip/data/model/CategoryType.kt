package com.achievemeaalk.freedjf.data.model

enum class CategoryType {
    EXPENSE, INCOME
} 