package com.achievemeaalk.freedjf.di

import javax.inject.Qualifier
import javax.inject.Singleton

@Qualifier
@Singleton
annotation class ApplicationScope
