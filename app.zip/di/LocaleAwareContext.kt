package com.achievemeaalk.freedjf.di

import javax.inject.Qualifier

@Qualifier
@Retention(AnnotationRetention.BINARY)
annotation class LocaleAwareContext